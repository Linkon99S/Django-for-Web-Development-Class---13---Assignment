from django.shortcuts import render, HttpResponseRedirect
from . forms import usercf
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import authenticate, login


# Create your views here.
def free_course(request):
    return render(request,'resources/freecourse.html', {'fcrs':5, 'platform':'S.H.Linkon'})

def blog(request):
    course1 = 'Machine Learning'
    course2 = 'Deep Learning'
    course3 = 'data analysis'
    course4 = 'Python with problem solving'
    freecourse_details={'c1':course1, 'c2':course2, 'c3':course3, 'c4':course4}
    return render(request,'resources/blog.html', freecourse_details)


def usercform(request):
    if request.method == "POST":
        frm = usercf(request.POST)
        if frm.is_valid():
            frm.save()
    else:        
        frm = usercf()
    return render(request, 'resources/usercform.html', {'form':frm})


def login_form(request):
    if request.method == 'POST':
        frm = AuthenticationForm(request=request, data = request.POST)
        if frm.is_valid():
            uname = frm.cleaned_data['username']
            upass = frm.cleaned_data['password']
            user = authenticate(username=uname, password= upass)
            if user is not None:
                login(request, user)
                return HttpResponseRedirect('/res/sucess')
    else:
        frm = AuthenticationForm()
    return render(request, 'resources/login.html', {'form':frm})


def slogin(request):
    return render(request, 'resources/success.html')