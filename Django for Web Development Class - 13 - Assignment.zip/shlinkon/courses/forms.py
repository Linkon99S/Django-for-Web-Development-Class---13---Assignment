from django import forms
from django.core import validators

class StudentRegistration(forms.Form):
    first_name = forms.CharField(label='Enter First Name', label_suffix='-', error_messages={'required':'Must be enter your first name'})
    last_name = forms.CharField()
    email = forms.EmailField()
    batch = forms.IntegerField(min_value=1)
    #phone_number = forms.IntegerField(widget=forms.HiddenInput())
    password = forms.CharField(widget=forms.PasswordInput(), min_length=8, max_length=25)
    re_password = forms.CharField(widget=forms.PasswordInput(), min_length=8, max_length=25)
    textarea = forms.CharField(widget=forms.Textarea())
    checkbox = forms.CharField(widget=forms.CheckboxInput())
    payment = forms.DecimalField(min_value=2500, max_value=4000, max_digits=6, decimal_places=2)


    def clean(self):
        cleaned_data = super().clean()
        password_match = self.cleaned_data['password']
        re_password_match = self.cleaned_data['re_password']
        if password_match != re_password_match:
            raise forms.ValidationError("Password doesnot match")