from django.shortcuts import render
from django.http import HttpResponse
from . models import Student, Info
from . forms import StudentRegistration
from django.http import HttpResponseRedirect

# Create your views here.
def course(request):
    return HttpResponse('Welcome Shahadot Hossain Linkon in Django for web & AI')

def data_science(request):
    available_course={'fcourse':['Machine Learning', 'Deep Learning', 'Data Analysis', 'Big Data', 'Django', 'AWS']}
    return render(request, 'courses/datascience.html', available_course)

def machine_learning(request):
    return render(request, 'courses/machinelearning.html')

def deep_learning(request):
    return render(request, 'courses/deeplearning.html')

def big_data(request):
    return render(request, 'courses/bigdata.html')

def home(request):
    return render(request, 'courses/home.html')

def student_info(request):
    sdetails = Student.objects.all()
    return render(request, 'courses/student.html', {'std':sdetails})

def show_form(request):
    if request.method=='POST':
        frm = StudentRegistration(request.POST)
        if frm.is_valid():
            fname =  frm.cleaned_data['first_name']
            lname =  frm.cleaned_data['last_name']
            eml =  frm.cleaned_data['email']
            btc =  frm.cleaned_data['batch']
            pas =  frm.cleaned_data['password']
            repass =  frm.cleaned_data['re_password']
            txt =  frm.cleaned_data['textarea']
            chk =  frm.cleaned_data['checkbox']
            pay =  frm.cleaned_data['payment']
            djangofour = Info(first_name = fname, last_name= lname, email= eml, batch=btc, password= pas, re_password= repass, textarea= txt, checkbox= chk, payment= pay)
            djangofour.save()
            return HttpResponseRedirect('/successfully/')
        
    else:
        frm = StudentRegistration(auto_id=True,)
        print('Execute GET')
    #frm.order_fields(field_order=['first_name','last_name','email','batch'])
    return render(request, 'courses/forms.html', {'form':frm})


def success(request):
    return render(request, 'courses/submit.html')
    

